### $Id: zzz.R,v 1.1 2004/12/03 16:11:20 sandy Exp $
###
### Dummy file to keep the R package manager happy.
